//Aqui vai o seu jQuery

$(document).ready(function() {
    // Após o carregamento da página via jQuery, ao clicar no botão "vermelho"  mudar a cor do fundo do menu para "vermelho" e a cor do seu texto para branca
    $('.j_btnCor').click(function() {
        $('.navbar').css('background', 'red');
        $('.navbar-nav a').css('color', 'white');
    });
    // Ao clicar no botão "azul"  remover a classe "navbar-default" e inserir a class "blue-blue" para mudar a cor do menu e do fundo
    $('.j_btnCorAzul').click(function() {
        $('.navbar-default').removeClass('navbar-default').addClass('blue-blue');
    });
    // Ao clicar no botão "Mostra Imagem", faça com que a classe "mostraImagem" apareça suavemente em 1500 milissegundos;
    $('.j_apareceImagem').click(function() {
        $('.mostraImagem').fadeIn(1500);
    });
    // Após o carregamento da imagem (exec. 3º), ao clicar botão "Subir", faça com que a classe mostraImagem suba, e sumindo da tela;
    $('.j_subir').click(function() {
        $('.mostraImagem').slideUp();
    });
    // Após o carregamento da imagem (exec. 3º), ao clicar botão "Descer", faça com que a classe mostraImagem desça, e apareça na tela;
    $('.j_descer').click(function() {
        $('.mostraImagem').slideDown();
    });
});
