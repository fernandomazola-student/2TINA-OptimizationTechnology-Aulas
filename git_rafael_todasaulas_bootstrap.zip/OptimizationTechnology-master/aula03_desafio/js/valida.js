function valida(){

	if(document.form.nome.value ==''){
		document.getElementById("resultado").style.display = "block";
		document.getElementById("resultado").innerHTML = "Informe um nome correto";
		document.form.nome.focus();
		return;
	}
	if(document.form.hora.value ==''){
		document.getElementById("resultado").style.display = "block";
		document.getElementById("resultado").innerHTML = "Informe a quantidade de horas trabalhadas";
		document.form.hora.focus();
		return;
	}
	if(document.form.dependentes.value ==''){
		document.getElementById("resultado").style.display = "block";
		document.getElementById("resultado").innerHTML = "Informe o numero de dependentes";
		document.form.dependentes.focus();
		return;
	}

	var nome = document.form.nome.value;
	var hora = document.form.hora.value;
	var dependentes = document.form.dependentes.value;

	calcular (nome, hora, dependentes);
}

function calcular (n,h,d){
		almentar = (h * 98) + (d * 80);
		ir = almentar * 0.05;
		inss = almentar * 0.085;
		salLiquido = (almentar - inss - ir);
		document.getElementById("resultado").style.display = "block";
		document.getElementById("resultado").innerHTML = 
		"<h3> Nome do funcionario: " +n+
		"<h3> R$ " + almentar.toFixed(2)+" Salario bruto <br>"+
		"<h3> R$ " + ir.toFixed(2)+ " ir <br>"+
		"<h3> R$ " + inss.toFixed(2) + " inss <br>"+
		"<h3> R$ " +salLiquido.toFixed(2) + " salario final";
		

}



function limit(element) {
	var max_caracter = 2;
	if (element.value.length > max_caracter) {
		element.value = element.value.substr(0,max_caracter);
	}
}

